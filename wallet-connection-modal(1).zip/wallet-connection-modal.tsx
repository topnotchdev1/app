"use client"

import { useState } from "react"
import Image from "next/image"
import { X, MoreHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function WalletConnectionModal() {
  const [isOpen, setIsOpen] = useState(true)

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900/50 p-4">
      {isOpen && (
        <div className="bg-gray-900 rounded-xl shadow-lg w-full max-w-md overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-gray-800">
            <div className="flex items-center gap-2">
              <div className="text-white font-medium text-lg">Connect Wallet</div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white transition-colors">
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="p-4">
            {/* WalletConnect */}
            <div className="flex items-center justify-between p-3 hover:bg-gray-800 rounded-lg transition-colors cursor-pointer mb-3">
              <div className="flex items-center gap-3">
                <div className="bg-blue-500 w-10 h-10 rounded-full flex items-center justify-center">
                  <Image
                    src="/placeholder.svg?height=40&width=40"
                    alt="WalletConnect"
                    width={24}
                    height={24}
                    className="rounded-full"
                  />
                </div>
                <div className="text-white font-medium">WalletConnect</div>
              </div>
              <div className="text-blue-500 text-sm font-medium">QR CODE</div>
            </div>

            {/* MetaMask */}
            <div className="flex items-center justify-between p-3 hover:bg-gray-800 rounded-lg transition-colors cursor-pointer mb-3">
              <div className="flex items-center gap-3">
                <div className="bg-orange-500 w-10 h-10 rounded-full flex items-center justify-center">
                  <Image
                    src="/placeholder.svg?height=40&width=40"
                    alt="MetaMask"
                    width={24}
                    height={24}
                    className="rounded-full"
                  />
                </div>
                <div className="text-white font-medium">MetaMask</div>
              </div>
              <div className="bg-green-600 text-white text-xs font-medium px-2 py-1 rounded">INSTALLED</div>
            </div>

            {/* All Wallets */}
            <div className="flex items-center justify-between p-3 hover:bg-gray-800 rounded-lg transition-colors cursor-pointer mb-3">
              <div className="flex items-center gap-3">
                <div className="bg-indigo-900 w-10 h-10 rounded-full flex items-center justify-center">
                  <div className="grid grid-cols-2 gap-1">
                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                  </div>
                </div>
                <div className="text-white font-medium">All Wallets</div>
              </div>
              <div className="text-gray-400 text-sm">440+</div>
            </div>

            {/* Divider */}
            <div className="flex items-center my-4">
              <div className="flex-1 border-t border-gray-800"></div>
              <div className="px-3 text-gray-500 text-sm">or</div>
              <div className="flex-1 border-t border-gray-800"></div>
            </div>

            {/* Email */}
            <div className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="text-gray-400">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect width="20" height="16" x="2" y="4" rx="2" />
                    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                  </svg>
                </div>
                <div className="text-gray-400">Email</div>
              </div>
              <div className="rounded-lg bg-gray-800 p-2 text-gray-400 text-sm">Enter your email address</div>
            </div>

            {/* Google */}
            <div className="flex items-center justify-between p-3 hover:bg-gray-800 rounded-lg transition-colors cursor-pointer mb-3">
              <div className="flex items-center gap-3">
                <div className="bg-white w-6 h-6 rounded-full flex items-center justify-center">
                  <Image
                    src="/placeholder.svg?height=24&width=24"
                    alt="Google"
                    width={16}
                    height={16}
                    className="rounded-full"
                  />
                </div>
                <div className="text-white font-medium">Continue With Google</div>
              </div>
            </div>

            {/* Social Logins */}
            <div className="flex justify-center gap-4 mt-6">
              <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center cursor-pointer">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M4 4l11.733 16h4.267l-11.733 -16z" />
                  <path d="M4 20l6.768 -6.768m2.46 -2.46l6.772 -6.772" />
                </svg>
              </div>
              <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center cursor-pointer">
                <Image
                  src="/placeholder.svg?height=24&width=24"
                  alt="Discord"
                  width={20}
                  height={20}
                  className="rounded-full"
                />
              </div>
              <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center cursor-pointer">
                <Image
                  src="/placeholder.svg?height=24&width=24"
                  alt="Alternative"
                  width={20}
                  height={20}
                  className="rounded-full"
                />
              </div>
              <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center cursor-pointer">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M9 19c-4.3 1.4 -4.3 -2.5 -6 -3m12 5v-3.5c0 -1 .1 -1.4 -.5 -2c2.8 -.3 5.5 -1.4 5.5 -6a4.6 4.6 0 0 0 -1.3 -3.2a4.2 4.2 0 0 0 -.1 -3.2s-1.1 -.3 -3.5 1.3a12.3 12.3 0 0 0 -6.2 0c-2.4 -1.6 -3.5 -1.3 -3.5 -1.3a4.2 4.2 0 0 0 -.1 3.2a4.6 4.6 0 0 0 -1.3 3.2c0 4.6 2.7 5.7 5.5 6c-.6 .6 -.6 1.2 -.5 2v3.5" />
                </svg>
              </div>
              <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center cursor-pointer">
                <MoreHorizontal className="h-5 w-5 text-white" />
              </div>
            </div>

            {/* No Wallet */}
            <div className="text-center mt-6 mb-2">
              <span className="text-gray-400 text-sm">Haven't got a wallet?</span>{" "}
              <a href="#" className="text-blue-500 text-sm">
                Get started
              </a>
            </div>

            {/* Footer */}
            <div className="text-center text-xs text-gray-500 mt-4 mb-2">
              UX by{" "}
              <span className="font-medium">
                <span className="text-gray-400">r</span>
                <span className="text-gray-300">e</span>
                <span className="text-gray-200">o</span>
                <span className="text-white">wn</span>
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Trigger Button */}
      {!isOpen && (
        <Button onClick={() => setIsOpen(true)} className="bg-blue-600 hover:bg-blue-700 text-white">
          Connect Wallet
        </Button>
      )}
    </div>
  )
}

