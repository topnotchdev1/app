export default function JQueryImplementation() {
  return (
    <div className="max-w-3xl mx-auto p-6 bg-gray-50 rounded-lg shadow-md">
      <h1 className="text-2xl font-bold mb-4">jQuery Implementation for Divi</h1>

      <div className="space-y-4">
        <p>Here's the jQuery code you would add to your WordPress site:</p>

        <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
          <pre className="text-sm">{`// wallet-modal.js
jQuery(document).ready(function($) {
  // Modal HTML structure
  const modalHTML = \`
    <div id="wallet-modal" class="wallet-modal">
      <div class="wallet-modal-content">
        <div class="wallet-modal-header">
          <h3>Connect Wallet</h3>
          <span class="wallet-close">&times;</span>
        </div>
        <div class="wallet-modal-body">
          <!-- WalletConnect -->
          <div class="wallet-option">
            <div class="wallet-icon wallet-icon-blue">
              <img src="/path-to-icons/walletconnect.png" alt="WalletConnect">
            </div>
            <div class="wallet-name">WalletConnect</div>
            <div class="wallet-action">QR CODE</div>
          </div>
          
          <!-- MetaMask -->
          <div class="wallet-option">
            <div class="wallet-icon wallet-icon-orange">
              <img src="/path-to-icons/metamask.png" alt="MetaMask">
            </div>
            <div class="wallet-name">MetaMask</div>
            <div class="wallet-badge">INSTALLED</div>
          </div>
          
          <!-- All Wallets -->
          <div class="wallet-option">
            <div class="wallet-icon wallet-icon-purple">
              <div class="wallet-dots">
                <span></span><span></span><span></span><span></span>
              </div>
            </div>
            <div class="wallet-name">All Wallets</div>
            <div class="wallet-count">440+</div>
          </div>
          
          <!-- Divider -->
          <div class="wallet-divider">
            <span>or</span>
          </div>
          
          <!-- Email -->
          <div class="wallet-email">
            <div class="wallet-email-label">
              <i class="wallet-email-icon"></i>
              <span>Email</span>
            </div>
            <input type="email" placeholder="Enter your email address" class="wallet-email-input">
          </div>
          
          <!-- Google -->
          <div class="wallet-option">
            <div class="wallet-icon wallet-icon-white">
              <img src="/path-to-icons/google.png" alt="Google">
            </div>
            <div class="wallet-name">Continue With Google</div>
          </div>
          
          <!-- Social Logins -->
          <div class="wallet-socials">
            <div class="wallet-social-icon wallet-social-x">
              <img src="/path-to-icons/x.png" alt="X">
            </div>
            <div class="wallet-social-icon wallet-social-discord">
              <img src="/path-to-icons/discord.png" alt="Discord">
            </div>
            <div class="wallet-social-icon wallet-social-alt">
              <img src="/path-to-icons/alt.png" alt="Alternative">
            </div>
            <div class="wallet-social-icon wallet-social-github">
              <img src="/path-to-icons/github.png" alt="GitHub">
            </div>
            <div class="wallet-social-icon wallet-social-more">
              <span>...</span>
            </div>
          </div>
          
          <!-- No Wallet -->
          <div class="wallet-help">
            <span>Haven't got a wallet?</span>
            <a href="#">Get started</a>
          </div>
          
          <!-- Footer -->
          <div class="wallet-footer">
            UX by <span class="wallet-brand">reown</span>
          </div>
        </div>
      </div>
    </div>
  \`;
  
  // Append modal to body
  $('body').append(modalHTML);
  
  // Show modal when button is clicked
  $('#connect-wallet-btn').on('click', function() {
    $('#wallet-modal').addClass('show');
  });
  
  // Close modal when X is clicked
  $('.wallet-close').on('click', function() {
    $('#wallet-modal').removeClass('show');
  });
  
  // Close modal when clicking outside
  $(window).on('click', function(event) {
    if ($(event.target).is('#wallet-modal')) {
      $('#wallet-modal').removeClass('show');
    }
  });
  
  // Wallet connection logic
  $('.wallet-option').on('click', function() {
    const walletName = $(this).find('.wallet-name').text();
    console.log('Connecting to ' + walletName);
    
    // Add your wallet connection logic here
    // For example:
    if (walletName === 'MetaMask') {
      connectMetaMask();
    } else if (walletName === 'WalletConnect') {
      connectWalletConnect();
    }
  });
  
  // Example MetaMask connection function
  function connectMetaMask() {
    if (typeof window.ethereum !== 'undefined') {
      window.ethereum.request({ method: 'eth_requestAccounts' })
        .then(accounts => {
          console.log('Connected:', accounts[0]);
          // Handle successful connection
        })
        .catch(error => {
          console.error('Connection error:', error);
        });
    } else {
      alert('MetaMask is not installed. Please install it to continue.');
    }
  }
  
  // Example WalletConnect function
  function connectWalletConnect() {
    // Implement WalletConnect logic
    console.log('WalletConnect functionality would go here');
  }
});`}</pre>
        </div>

        <p className="mt-4">And here's the CSS you would add:</p>

        <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
          <pre className="text-sm">{`/* wallet-modal.css */
.wallet-modal {
  display: none;
  position: fixed;
  z-index: 9999;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  align-items: center;
  justify-content: center;
}

.wallet-modal.show {
  display: flex;
}

.wallet-modal-content {
  background-color: #1a1a1a;
  border-radius: 12px;
  max-width: 400px;
  width: 100%;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
  overflow: hidden;
}

.wallet-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px;
  border-bottom: 1px solid #333;
}

.wallet-modal-header h3 {
  color: white;
  margin: 0;
  font-size: 18px;
}

.wallet-close {
  color: #aaa;
  font-size: 24px;
  cursor: pointer;
}

.wallet-close:hover {
  color: white;
}

.wallet-modal-body {
  padding: 16px;
}

.wallet-option {
  display: flex;
  align-items: center;
  padding: 12px;
  border-radius: 8px;
  margin-bottom: 12px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.wallet-option:hover {
  background-color: #333;
}

.wallet-icon {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 12px;
}

.wallet-icon img {
  width: 24px;
  height: 24px;
}

.wallet-icon-blue {
  background-color: #3b82f6;
}

.wallet-icon-orange {
  background-color: #f97316;
}

.wallet-icon-purple {
  background-color: #4338ca;
}

.wallet-icon-white {
  background-color: white;
}

.wallet-dots {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4px;
}

.wallet-dots span {
  width: 8px;
  height: 8px;
  background-color: #818cf8;
  border-radius: 50%;
}

.wallet-name {
  color: white;
  font-weight: 500;
  flex-grow: 1;
}

.wallet-action {
  color: #3b82f6;
  font-size: 14px;
  font-weight: 500;
}

.wallet-badge {
  background-color: #22c55e;
  color: white;
  font-size: 12px;
  font-weight: 500;
  padding: 4px 8px;
  border-radius: 4px;
}

.wallet-count {
  color: #9ca3af;
  font-size: 14px;
}

.wallet-divider {
  display: flex;
  align-items: center;
  margin: 16px 0;
}

.wallet-divider:before,
.wallet-divider:after {
  content: "";
  flex-grow: 1;
  border-top: 1px solid #333;
}

.wallet-divider span {
  padding: 0 12px;
  color: #6b7280;
  font-size: 14px;
}

.wallet-email {
  margin-bottom: 16px;
}

.wallet-email-label {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #9ca3af;
  margin-bottom: 8px;
}

.wallet-email-input {
  width: 100%;
  background-color: #333;
  border: none;
  border-radius: 8px;
  padding: 12px;
  color: #9ca3af;
  font-size: 14px;
}

.wallet-socials {
  display: flex;
  justify-content: center;
  gap: 16px;
  margin-top: 24px;
}

.wallet-social-icon {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.wallet-social-icon img {
  width: 20px;
  height: 20px;
}

.wallet-social-x {
  background-color: black;
}

.wallet-social-discord {
  background-color: #5865f2;
}

.wallet-social-alt {
  background-color: #9333ea;
}

.wallet-social-github {
  background-color: #333;
}

.wallet-social-more {
  background-color: #333;
  color: white;
  font-size: 18px;
}

.wallet-help {
  text-align: center;
  margin-top: 24px;
  margin-bottom: 8px;
}

.wallet-help span {
  color: #9ca3af;
  font-size: 14px;
}

.wallet-help a {
  color: #3b82f6;
  font-size: 14px;
  text-decoration: none;
}

.wallet-footer {
  text-align: center;
  color: #6b7280;
  font-size: 12px;
  margin-top: 16px;
  margin-bottom: 8px;
}

.wallet-brand {
  font-weight: 500;
  background: linear-gradient(90deg, #6b7280, #e5e7eb, #f9fafb, #ffffff);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}`}</pre>
        </div>
      </div>

      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-2">Adding to functions.php</h2>
        <p>Add this code to your theme's functions.php file or in a custom plugin:</p>

        <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto mt-2">
          <pre className="text-sm">{`/**
 * Enqueue Wallet Modal scripts and styles
 */
function wallet_modal_scripts() {
  // Enqueue jQuery (WordPress already includes it)
  wp_enqueue_script('jquery');
  
  // Enqueue our custom script
  wp_enqueue_script(
    'wallet-modal-js',
    get_stylesheet_directory_uri() . '/js/wallet-modal.js',
    array('jquery'),
    '1.0.0',
    true
  );
  
  // Enqueue our custom styles
  wp_enqueue_style(
    'wallet-modal-css',
    get_stylesheet_directory_uri() . '/css/wallet-modal.css',
    array(),
    '1.0.0'
  );
}
add_action('wp_enqueue_scripts', 'wallet_modal_scripts');`}</pre>
        </div>
      </div>
    </div>
  )
}

