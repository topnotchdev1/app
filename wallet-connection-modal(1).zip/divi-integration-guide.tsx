export default function DiviIntegrationGuide() {
  return (
    <div className="max-w-3xl mx-auto p-6 bg-white rounded-lg shadow-md">
      <h1 className="text-2xl font-bold mb-4">How to Integrate the Wallet Modal in Divi WordPress</h1>

      <div className="space-y-6">
        <section>
          <h2 className="text-xl font-semibold mb-2">Step 1: Install Required Plugins</h2>
          <p className="mb-2">First, install these plugins in your WordPress site:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li>Divi Builder (if not already using the Divi theme)</li>
            <li>Code Snippets or Custom HTML plugin</li>
            <li>Optional: Advanced Custom Fields for additional functionality</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">Step 2: Convert React Component to WordPress</h2>
          <p className="mb-2">Since Divi uses jQuery and not React, you'll need to convert the component:</p>
          <ol className="list-decimal pl-6 space-y-1">
            <li>
              Create a new file called <code>wallet-modal.js</code> with the jQuery version
            </li>
            <li>
              Create a <code>wallet-modal.css</code> file with the styles
            </li>
            <li>Enqueue these files in your theme's functions.php</li>
          </ol>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">Step 3: Add to Divi</h2>
          <p className="mb-2">Add the modal to your Divi site:</p>
          <ol className="list-decimal pl-6 space-y-2">
            <li>
              <p className="font-medium">Using Code Module:</p>
              <p>Add a Code Module to your Divi page and paste this code:</p>
              <div className="bg-gray-100 p-3 rounded text-sm overflow-x-auto">
                <pre>{`<div id="wallet-connection-modal"></div>
<button id="connect-wallet-btn" class="et_pb_button">Connect Wallet</button>`}</pre>
              </div>
            </li>
            <li>
              <p className="font-medium">Using Theme Builder:</p>
              <p>Add the code to a global section in the Divi Theme Builder</p>
            </li>
          </ol>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">Step 4: Customize the Design</h2>
          <p className="mb-2">Customize the modal to match your site:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li>Update colors in the CSS file to match your brand</li>
            <li>Replace placeholder images with actual wallet icons</li>
            <li>Adjust the modal size and positioning as needed</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">Step 5: Add Functionality</h2>
          <p className="mb-2">Implement the wallet connection functionality:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li>Add Web3 libraries like Web3.js or Ethers.js</li>
            <li>Implement actual wallet connection logic for each provider</li>
            <li>Add authentication flows for email and social logins</li>
          </ul>
        </section>
      </div>

      <div className="mt-8 p-4 bg-blue-50 rounded-lg">
        <h3 className="text-lg font-semibold text-blue-800 mb-2">Need Help?</h3>
        <p>
          For more advanced integration, you might need to use a dedicated Web3 WordPress plugin or hire a developer
          familiar with both WordPress and Web3 technologies.
        </p>
      </div>
    </div>
  )
}

