"use client"

import WalletConnectionModal from "../wallet-connection-modal"

export default function SyntheticV0PageForDeployment() {
  return <WalletConnectionModal />
}