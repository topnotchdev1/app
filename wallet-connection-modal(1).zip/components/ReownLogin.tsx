"use client"

import { signIn, signOut, useSession } from "next-auth/react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ReownLogin() {
  const { data: session } = useSession()
  const [email, setEmail] = useState("")

  if (session) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Welcome, {session.user.email}</CardTitle>
        </CardHeader>
        <CardContent>
          <Button onClick={() => signOut()}>Sign out</Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sign in with Reown</CardTitle>
      </CardHeader>
      <CardContent>
        <form
          onSubmit={(e) => {
            e.preventDefault()
            signIn("reown", { email })
          }}
        >
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="mb-4"
          />
          <Button type="submit">Sign in</Button>
        </form>
      </CardContent>
    </Card>
  )
}

