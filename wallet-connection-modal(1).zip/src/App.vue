<script setup>
import { ref } from 'vue'
import { createAppKit, useAppKit } from '@reown/appkit/vue'
import { WagmiProvider } from 'wagmi'
import { arbitrum, mainnet } from '@reown/appkit/networks'
import { WagmiAdapter } from '@reown/appkit-adapter-wagmi'

const projectId = 'b1d30079a20735ebc09e0d549ea529b8'

const metadata = {
  name: 'TOI Pay',
  description: 'AppKit Example',
  url: 'https://www.npntoi.com', // Updated URL
  icons: ['https://assets.reown.com/reown-profile-pic.png']
}

export const networks = [mainnet, arbitrum]

const wagmiAdapter = new WagmiAdapter({
  ssr: false, // Set to false for client-side only
  projectId,
  networks
})

const appKit = createAppKit({
  adapters: [wagmiAdapter],
  networks: [mainnet, arbitrum],
  metadata,
  projectId,
  features: {
    analytics: true
  }
})

const modal = useAppKit()

const isAuthenticated = ref(false)
const userEmail = ref('')

async function handleConnect() {
  try {
    await modal.open()
    const session = appKit.getSession()
    if (session) {
      const response = await fetch('https://www.npntoi.com/wp-json/reown/v1/auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ token: session.token }),
      })
      const data = await response.json()
      if (data.success) {
        isAuthenticated.value = true
        userEmail.value = data.user_email
      }
    }
  } catch (error) {
    console.error('Authentication error:', error)
  }
}
</script>

<template>
  <div>
    <button v-if="!isAuthenticated" @click="handleConnect">Connect Wallet</button>
    <div v-else>
      Welcome, {{ userEmail }}!
      <button @click="modal.logout()">Logout</button>
    </div>
  </div>
</template>

