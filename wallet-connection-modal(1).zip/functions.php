function custom_login_page() {
    wp_redirect('https://your-vercel-app.vercel.app/login');
    exit();
}
add_action('login_init', 'custom_login_page');

