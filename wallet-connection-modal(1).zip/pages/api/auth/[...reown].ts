import { ReownAdapter } from "@reown/auth"
import NextAuth from "next-auth"

export default NextAuth({
  providers: [
    ReownAdapter({
      clientId: process.env.REOWN_CLIENT_ID,
      clientSecret: process.env.REOWN_CLIENT_SECRET,
      // Add any other required configuration options
    }),
  ],
  // Add any additional NextAuth configuration
})

