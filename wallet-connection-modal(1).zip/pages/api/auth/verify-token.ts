import { getToken } from "next-auth/jwt"
import type { NextApiRequest, NextApiResponse } from "next"

const secret = process.env.NEXTAUTH_SECRET

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const token = await getToken({ req, secret })

  if (token) {
    // Token is valid
    res.json({ valid: true, user: { id: token.sub, email: token.email } })
  } else {
    // Token is invalid
    res.status(401).json({ valid: false })
  }
}

