import NextAuth from "next-auth"
import { ReownAdapter } from "@reown/auth"

export default NextAuth({
  providers: [
    ReownAdapter({
      clientId: process.env.REOWN_CLIENT_ID,
      clientSecret: process.env.REOWN_CLIENT_SECRET,
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
      }
      return token
    },
    async session({ session, token }) {
      session.user.id = token.id
      return session
    },
  },
})

