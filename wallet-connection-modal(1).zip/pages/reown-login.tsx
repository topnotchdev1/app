import { SessionProvider } from "next-auth/react"
import ReownLogin from "../components/ReownLogin"
import ReactDOM from "react-dom"

export default function ReownLoginPage() {
  return (
    <SessionProvider>
      <ReownLogin />
    </SessionProvider>
  )
}

if (typeof window !== "undefined") {
  // @ts-ignore
  window.ReownLogin = {
    render: (containerId: string) => {
      const container = document.getElementById(containerId)
      if (container) {
        ReactDOM.render(
          <SessionProvider>
            <ReownLogin />
          </SessionProvider>,
          container,
        )
      }
    },
  }
}

